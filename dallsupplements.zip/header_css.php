<link rel="apple-touch-icon" href="apple-touch-icon.png">
<!-- Place favicon.ico in the root directory -->


<!-- =========================
        Loding All Stylesheet
    ============================== -->
<link rel="stylesheet" href="css/hover-min.css">
<link rel="stylesheet" href="css/magnific-popup.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/flexslider.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">

<!-- =========================
        Loding Main Theme Style
    ============================== -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/color.css">
<link rel="stylesheet" href="css/private_policy.css">
<link rel="stylesheet" href="css/term_condition.css">

<!-- =========================
    	Header Loding JS Script
    ============================== -->
<script src="js/modernizr.js"></script>